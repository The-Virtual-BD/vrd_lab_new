import React from "react";
import ProjectDetails from "../../components/Pages/ProjectDetails";

const projectDetails = () => {
	return (
		<div>
			<ProjectDetails />
		</div>
	);
};

export default projectDetails;
