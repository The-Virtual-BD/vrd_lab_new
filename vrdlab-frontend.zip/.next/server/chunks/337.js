"use strict";
exports.id = 337;
exports.ids = [337];
exports.modules = {

/***/ 9337:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ZP": () => (/* binding */ ContextData),
  "Kx": () => (/* binding */ useCollection)
});

// UNUSED EXPORTS: AppContext

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(1175);
// EXTERNAL MODULE: ./url.js
var url = __webpack_require__(8742);
;// CONCATENATED MODULE: ./components/Context/fetching.js

//Fetch Products
const fetchProjects = async ()=>{
    const res = await fetch(`${url/* baseUrl */.F}/projects/all`);
    const data = await res.json();
    return data?.data;
};
//Fetch News
const fetchNews = async ()=>{
    const res = await fetch(`${url/* baseUrl */.F}/news/all`);
    const data = await res.json();
    return data?.data;
};
//Fetch Teams
const fetchTeams = async ()=>{
    const res = await fetch(`${url/* baseUrl */.F}/team/all`);
    const data = await res.json();
    return data?.data;
};
//Fetch Work
const fetchPublications = async ()=>{
    const res = await fetch(`${url/* baseUrl */.F}/publications/all`);
    const data = await res.json();
    return data?.data;
};

;// CONCATENATED MODULE: ./components/Context/ContextData.js





const AppContext = /*#__PURE__*/ (0,external_react_.createContext)();
const DataCollection = ({ children  })=>{
    const { data: projects , isLoading: projectsLoading  } = (0,external_react_query_.useQuery)("projects", fetchProjects);
    const { data: news , isLoading: newsLoading  } = (0,external_react_query_.useQuery)("news", fetchNews);
    const { data: teams , isLoading: teamLoading  } = (0,external_react_query_.useQuery)("teams", fetchTeams);
    const { data: publications , isLoading: publicationsLoading  } = (0,external_react_query_.useQuery)("publications", fetchPublications);
    const value = {
        projects,
        projectsLoading,
        news,
        newsLoading,
        teams,
        teamLoading,
        publications,
        publicationsLoading
    };
    //   console.log(projects,news)
    return /*#__PURE__*/ jsx_runtime_.jsx(AppContext.Provider, {
        value: value,
        children: children
    });
};
//Create Hooks for send data
const useCollection = ()=>{
    const context = (0,external_react_.useContext)(AppContext);
    return context;
};
/* harmony default export */ const ContextData = (DataCollection);


/***/ }),

/***/ 8742:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ baseUrl)
/* harmony export */ });
const baseUrl = `https://backend.vrdlab.com`;


/***/ })

};
;