import React from "react";
import News from "../../components/Pages/News";

const index = () => {
	return (
		<div>
			<News />
		</div>
	);
};

export default index;
