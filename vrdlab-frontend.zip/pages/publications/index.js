import React from 'react';
import Publications from '../../components/Pages/Publications';

const index = () => {
    return (
        <div>
            <Publications />
        </div>
    );
};

export default index;