import React from "react";
import NewsDetails from "../../components/Pages/NewsDetails";

const newsDetails = () => {
	return (
		<div>
			<NewsDetails />
		</div>
	);
};

export default newsDetails;
