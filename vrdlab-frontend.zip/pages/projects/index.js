import React from 'react';
import Projects from '../../components/Pages/Projects';

const index = () => {
    return (
        <div>
            <Projects />
        </div>
    );
};

export default index;