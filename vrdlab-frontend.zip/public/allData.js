export const publication = [
	{
		id: 1,
		title: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptatum",
		category: "Deep Learning",
		details: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit optio quibusdam suscipit omnis deserunt, quia molestiae dolorem officiis ab fugit?",
        btnLink:"/",
		img: "/assets/publication.png",
	},
	{
		id: 2,
		title: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptatum2",
		category: "Deep Learning",
		details: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit optio quibusdam suscipit omnis deserunt, quia molestiae dolorem officiis ab fugit?",
        btnLink:"/",
		img: "/assets/publication.png",
	},
	{
		id: 3,
		title: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptatum3",
		category: "Deep Learning",
		details: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit optio quibusdam suscipit omnis deserunt, quia molestiae dolorem officiis ab fugit?",
        btnLink:"/",
		img: "/assets/publication.png",
	},
	{
		id: 4,
		title: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptatum2",
		category: "Deep Learning",
		details: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit optio quibusdam suscipit omnis deserunt, quia molestiae dolorem officiis ab fugit?",
        btnLink:"/",
		img: "/assets/publication.png",
	},
	{
		id: 5,
		title: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Voluptatum3",
		category: "Deep Learning",
		details: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit optio quibusdam suscipit omnis deserunt, quia molestiae dolorem officiis ab fugit?",
        btnLink:"/",
		img: "/assets/publication.png",
	},
];

