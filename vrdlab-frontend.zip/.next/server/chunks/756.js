"use strict";
exports.id = 756;
exports.ids = [756];
exports.modules = {

/***/ 6756:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony exports newsData, membersData, publicationsData */
const newsData = [
    {
        id: 1,
        title: "Exploring Anatomy & Physiology in the Laboratory",
        details: "Vestibulum lacus dui, commodo sed sollicitudin nec, accumsan at magna. Pellentesque tempor, odio sed accumsan pretium, diam justo iaculis justo, vel aliquet diam mauris et eros"
    },
    {
        id: 2,
        title: "Exploring Anatomy  Physiology in the Laboratory",
        details: "Vestibulum lacus dui, commodo sed sollicitudin nec, accumsan at magna. Pellentesque tempor, odio sed accumsan pretium, diam justo iaculis justo, vel aliquet diam mauris et eros"
    },
    {
        id: 3,
        title: "Exploring Anatomy  Physiology in the Laboratory",
        details: "Vestibulum lacus dui, commodo sed sollicitudin nec, accumsan at magna. Pellentesque tempor, odio sed accumsan pretium, diam justo iaculis justo, vel aliquet diam mauris et eros"
    }
];
const membersData = [
    {
        id: 1,
        name: "Md. Shoriful Islam",
        desi: "Associate Professor",
        img: "/assets/sariful-islam.jpg"
    },
    {
        id: 2,
        name: "Md. Mehedi Hasan ",
        desi: "Lecturer",
        img: "/assets/mehedi-hasan.jpg"
    },
    {
        id: 3,
        name: "Md. Shoriful Islam",
        desi: "Associate Professor",
        img: "/assets/sariful-islam.jpg"
    },
    {
        id: 4,
        name: "Md. Shoriful Islam",
        desi: "Associate Professor",
        img: "/assets/sariful-islam.jpg"
    },
    {
        id: 5,
        name: "Md. Shoriful Islam",
        desi: "Associate Professor",
        img: "/assets/sariful-islam.jpg"
    },
    {
        id: 6,
        name: "Md. Shoriful Islam",
        desi: "Associate Professor",
        img: "/assets/sariful-islam.jpg"
    }
];
const publicationsData = [
    {
        id: 1,
        title: "A. Jamgochian, A. Corso, and M. J. Kochenderfer, “Online planning for constrained POMDPs with continuous spaces through dual ascent,” in International Conference on Automated Planning and Scheduling (ICAPS), 2023.",
        btnLink: "/"
    },
    {
        id: 2,
        title: "A. Jamgochian, A. Corso, and M. J. Kochenderfer, “Online planning for constrained POMDPs with continuous spaces through dual ascent,” in International Conference on Automated Planning and Scheduling (ICAPS), 2023.",
        btnLink: "/"
    },
    {
        id: 3,
        title: "A. Jamgochian, A. Corso, and M. J. Kochenderfer, “Online planning for constrained POMDPs with continuous spaces through dual ascent,” in International Conference on Automated Planning and Scheduling (ICAPS), 2023.",
        btnLink: "/"
    },
    {
        id: 4,
        title: "A. Jamgochian, A. Corso, and M. J. Kochenderfer, “Online planning for constrained POMDPs with continuous spaces through dual ascent,” in International Conference on Automated Planning and Scheduling (ICAPS), 2023.",
        btnLink: "/"
    },
    {
        id: 5,
        title: "A. Jamgochian, A. Corso, and M. J. Kochenderfer, “Online planning for constrained POMDPs with continuous spaces through dual ascent,” in International Conference on Automated Planning and Scheduling (ICAPS), 2023.",
        btnLink: "/"
    },
    {
        id: 6,
        title: "A. Jamgochian, A. Corso, and M. J. Kochenderfer, “Online planning for constrained POMDPs with continuous spaces through dual ascent,” in International Conference on Automated Planning and Scheduling (ICAPS), 2023.",
        btnLink: "/"
    }
];


/***/ })

};
;