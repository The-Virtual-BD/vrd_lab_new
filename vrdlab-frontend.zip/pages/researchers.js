import React from 'react';
import Researchers from '../components/Pages/Researchers';

const index = () => {
    return (
        <div>
            <Researchers />
        </div>
    );
};

export default index;